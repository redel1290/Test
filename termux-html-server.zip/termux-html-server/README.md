# HTML Live Server для Termux

Простий інструмент для швидкого запуску локального HTML сервера в Termux.

## 📦 Встановлення

### Через pip (рекомендовано)

```bash
pip install termux-html-server
```

### Або з GitHub

```bash
pip install git+https://github.com/yourusername/termux-html-server.git
```

### Або локально

```bash
git clone https://github.com/yourusername/termux-html-server.git
cd termux-html-server
pip install .
```

## 🚀 Використання

1. Запустіть команду:
```bash
html
```

2. Введіть ваш HTML код

Приклад:
```html
<!DOCTYPE html>
<html>
<head>
    <title>Мій сайт</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }
        h1 { color: #333; }
    </style>
</head>
<body>
    <h1>Привіт, світ! 🌍</h1>
    <p>Це мій локальний сайт в Termux!</p>
</body>
</html>
```

3. Після введення коду натисніть **Ctrl+G**

4. Введіть порт (наприклад, `8080`)

5. Відкрийте браузер: `http://localhost:8080`

6. Для зупинки натисніть **Ctrl+C** (миттєва зупинка)

## ✨ Особливості

- ✅ Швидкий запуск через команду `html`
- ✅ Не зберігає код після зупинки
- ✅ Вибір довільного порту
- ✅ Автоматична перевірка доступності порту
- ✅ Миттєва зупинка сервера (Ctrl+C)
- ✅ Без логів запитів (чистий вивід)
- ✅ Легке встановлення через pip

## 🎯 Приклади використання

### Простий HTML
```bash
html
```
```html
<!DOCTYPE html>
<html><body><h1>Test</h1></body></html>
```
Ctrl+G → Введіть порт → Готово!

### З CSS та JavaScript
```html
<!DOCTYPE html>
<html>
<head>
    <style>
        .container { padding: 20px; }
        button { padding: 10px 20px; font-size: 16px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Лічильник</h1>
        <p id="count">0</p>
        <button onclick="increment()">+1</button>
    </div>
    <script>
        let count = 0;
        function increment() {
            count++;
            document.getElementById('count').textContent = count;
        }
    </script>
</body>
</html>
```

## 🎮 Керування

- **Введення коду** - Пишіть багаторядковий HTML
- **Ctrl+G** - Завершити введення та запустити
- **Ctrl+C** - Миттєво зупинити сервер і вийти

## 📋 Вимоги

- Python 3.6+
- Termux (або інший Linux термінал)

## 🗑️ Видалення

```bash
pip uninstall termux-html-server
```

## 🔒 Безпека

- HTML код зберігається тільки в тимчасовій пам'яті
- Сервер доступний тільки локально (127.0.0.1)
- Після зупинки всі файли автоматично видаляються

## 📝 Примітки

- Рекомендовані порти: 8000-9000
- Порт має бути в діапазоні 1024-65535
- Логи запитів вимкнені для чистого виводу
- Зупинка сервера миттєва без затримок
- Рекомендовані порти: 8000-9000
- Порт має бути в діапазоні 1024-65535

## 🐛 Проблеми?

Якщо виникли проблеми, перевірте:
1. Чи встановлений Python: `python --version`
2. Чи не зайнятий порт: `netstat -tlnp | grep :8080`

## 📜 Ліцензія

MIT License

## 👨‍💻 Автор

**Lunyx** - Створено для Termux користувачів 🚀

---

**Приємного кодування!** ✨
