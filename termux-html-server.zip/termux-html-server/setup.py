from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="termux-html-server",
    version="1.2.0",
    author="Lunyx",
    author_email="",
    description="Швидкий запуск локального HTML сервера в Termux",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/termux-html-server",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Android",
        "Environment :: Console",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "html=termux_html_server.main:main",
        ],
    },
    install_requires=[],
)
