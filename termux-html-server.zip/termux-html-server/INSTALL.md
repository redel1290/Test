# Інструкція з встановлення

## Варіант 1: Встановлення через pip (найпростіше)

### В Termux:

```bash
# Встановлення
pip install termux-html-server

# Використання
html
```

## Варіант 2: Встановлення з локального файлу

```bash
# 1. Розпакуйте ZIP архів
unzip termux-html-server.zip
cd termux-html-server

# 2. Встановіть пакет
pip install .

# 3. Готово! Тепер можна використовувати
html
```

## Варіант 3: Встановлення з GitHub (якщо завантажите туди)

```bash
pip install git+https://github.com/yourusername/termux-html-server.git
```

## Перевірка встановлення

```bash
# Перевірте чи команда доступна
which html

# Або запустіть
html
```

## Видалення

```bash
pip uninstall termux-html-server
```

## Troubleshooting

### Якщо команда `html` не знайдена:

1. Перевірте чи встановлено пакет:
```bash
pip list | grep termux-html-server
```

2. Переконайтеся що pip bin директорія в PATH:
```bash
echo $PATH
```

3. Знайдіть де встановлено:
```bash
pip show termux-html-server
```

### Якщо помилка при встановленні:

```bash
# Оновіть pip
pip install --upgrade pip

# Спробуйте ще раз
pip install termux-html-server
```

## Приклад використання

```bash
$ html
╔════════════════════════════════════════╗
║   HTML Live Server для Termux         ║
╚════════════════════════════════════════╝

📝 ІНСТРУКЦІЯ:
  1. Введіть HTML код нижче
  2. Натисніть Ctrl+G щоб запустити сервер
  3. Або Ctrl+C для виходу
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Введіть ваш HTML код (Ctrl+G для завершення):

<!DOCTYPE html>
<html>
<body>
    <h1>Hello World!</h1>
</body>
</html>

[Натисніть Ctrl+G]

🔌 Введіть порт для запуску (наприклад, 8080): 8080

🚀 Запуск сервера на порту 8080
📱 Відкрийте в браузері: http://localhost:8080
🛑 Для зупинки натисніть Ctrl+C
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Готово! 🎉
