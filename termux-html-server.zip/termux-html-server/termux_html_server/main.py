#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import tempfile
import signal
import threading
import tty
import termios
from http.server import HTTPServer, SimpleHTTPRequestHandler
import socket

def clear_screen():
    """Очищає термінал"""
    os.system('clear' if os.name != 'nt' else 'cls')

def print_header():
    """Виводить заголовок"""
    print("╔════════════════════════════════════════╗")
    print("║   HTML Live Server для Termux         ║")
    print("╚════════════════════════════════════════╝")
    print()
    print("📝 ІНСТРУКЦІЯ:")
    print("  1. Введіть HTML код нижче")
    print("  2. Натисніть Ctrl+G щоб запустити сервер")
    print("  3. Або Ctrl+C для виходу")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()

def check_port_available(port):
    """Перевіряє чи порт доступний"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('127.0.0.1', port))
    sock.close()
    return result != 0

def start_server(html_content, port):
    """Запускає HTTP сервер"""
    # Створюємо тимчасову директорію
    temp_dir = tempfile.mkdtemp()
    index_file = os.path.join(temp_dir, 'index.html')
    
    # Зберігаємо HTML
    with open(index_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # Змінюємо робочу директорію
    os.chdir(temp_dir)
    
    # Створюємо сервер
    handler = SimpleHTTPRequestHandler
    
    # Вимикаємо логування для чистого виводу
    class QuietHandler(SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # Не виводимо логи
    
    httpd = HTTPServer(('127.0.0.1', port), QuietHandler)
    
    print()
    print("🚀 Запуск сервера на порту", port)
    print(f"📱 Відкрийте в браузері: http://localhost:{port}")
    print("🛑 Для зупинки натисніть Ctrl+C")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()
    
    server_running = True
    
    def cleanup(signum=None, frame=None):
        """Очищення при виході"""
        nonlocal server_running
        if not server_running:
            return
        server_running = False
        
        print("\n🛑 Зупинка сервера...")
        
        # Швидко зупиняємо сервер
        try:
            httpd.shutdown()
            httpd.server_close()
        except:
            pass
        
        # Видаляємо тимчасові файли
        try:
            os.remove(index_file)
            os.rmdir(temp_dir)
        except:
            pass
        
        print("✅ Сервер зупинено")
        sys.exit(0)
    
    # Встановлюємо обробники сигналів
    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)
    
    # Запускаємо сервер в окремому потоці
    server_thread = threading.Thread(target=httpd.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    
    try:
        # Чекаємо на Ctrl+C
        while server_running:
            try:
                signal.pause()
            except KeyboardInterrupt:
                cleanup()
                break
    except KeyboardInterrupt:
        cleanup()

def read_html_with_ctrl_g():
    """Читає HTML код з підтримкою Ctrl+G"""
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    
    try:
        # Встановлюємо cbreak режим замість raw для кращої сумісності
        tty.setcbreak(fd)
        html_lines = []
        current_line = ""
        
        print("Введіть ваш HTML код (Ctrl+G для завершення):")
        print()
        
        while True:
            char = sys.stdin.read(1)
            char_code = ord(char)
            
            # Ctrl+G (ASCII 7) - завершити введення
            if char_code == 7:
                # Відновлюємо термінал перед виходом
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                if current_line:
                    html_lines.append(current_line)
                print()  # Новий рядок після Ctrl+G
                return '\n'.join(html_lines)
            
            # Ctrl+C (ASCII 3) - скасувати
            elif char_code == 3:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                print("\n❌ Скасовано")
                sys.exit(0)
            
            # Enter/Return (ASCII 10 - LF або 13 - CR)
            elif char_code in (10, 13):
                html_lines.append(current_line)
                current_line = ""
                # В cbreak mode потрібно явно виводити \r\n
                sys.stdout.write('\r\n')
                sys.stdout.flush()
            
            # Backspace/Delete (ASCII 127 - DEL або 8 - BS)
            elif char_code in (127, 8):
                if current_line:
                    current_line = current_line[:-1]
                    # Стираємо символ: назад, пробіл, назад
                    sys.stdout.write('\b \b')
                    sys.stdout.flush()
            
            # Звичайні друковані символи та табуляція
            elif char_code >= 32 or char_code == 9:  # 9 = TAB
                current_line += char
                sys.stdout.write(char)
                sys.stdout.flush()
            
            # Ігноруємо інші control characters
    
    except Exception as e:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        raise e
    
    finally:
        # Гарантуємо відновлення налаштувань терміналу
        try:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        except:
            pass

def main():
    """Основна функція"""
    try:
        clear_screen()
        print_header()
        
        # Читаємо HTML код з підтримкою Ctrl+G
        html_content = read_html_with_ctrl_g()
        
        # Перевіряємо чи є контент
        if not html_content.strip():
            print("\n❌ Помилка: HTML код порожній!")
            sys.exit(1)
        
        # Запитуємо порт
        print()
        while True:
            try:
                port_input = input("🔌 Введіть порт для запуску (наприклад, 8080): ")
                port = int(port_input)
                
                if port < 1024 or port > 65535:
                    print("❌ Порт має бути в діапазоні 1024-65535")
                    continue
                
                if not check_port_available(port):
                    print(f"❌ Порт {port} вже зайнятий. Спробуйте інший.")
                    continue
                
                break
            except ValueError:
                print("❌ Введіть коректне число")
            except KeyboardInterrupt:
                print("\n❌ Скасовано")
                sys.exit(0)
        
        # Запускаємо сервер
        start_server(html_content, port)
        
    except KeyboardInterrupt:
        print("\n👋 До побачення!")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Помилка: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
