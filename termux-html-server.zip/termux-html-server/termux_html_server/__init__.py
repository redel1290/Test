"""
Termux HTML Server - Швидкий запуск локального HTML сервера
"""

__version__ = "1.2.0"
__author__ = "Lunyx"
